package com.genspark.KafkaCCProducer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaCcProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaCcProducerApplication.class, args);
	}

}
