package com.genspark.KafkaCCProducer.util;

public class AppConstants {
    public static final String TOPIC_NAME="currency_conversion";
}
