package com.genspark.joindemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoindemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
