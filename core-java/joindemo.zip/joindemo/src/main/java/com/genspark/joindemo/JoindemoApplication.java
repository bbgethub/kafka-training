package com.genspark.joindemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoindemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoindemoApplication.class, args);
	}

}
